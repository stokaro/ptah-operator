//go:build e2e

package e2e

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"github.com/stokaro/ptah-operator/test/e2e/harness"
	"github.com/stokaro/ptah-operator/test/e2e/phases"
	"os"
	"os/exec"
	"path/filepath"
	"testing"
	"time"
)

// Focused retained-lab diagnostics; no full-phase completion record is emitted.
func TestMain(m *testing.M) { os.Exit(m.Run()) }
func TestRetainedRemainingDataPlane(t *testing.T) {
	in, err := phases.Load(phases.DataPlane, os.LookupEnv)
	if err != nil {
		t.Fatal(err)
	}
	d := newRetainedDataPlane(t, in)
	f := newFaultRun(d)
	f.buildScanner()
	f.pgReference = "oci://" + f.registryHost + "/schemas/fault-postgresql:stable"
	f.mysqlReference = "oci://" + f.registryHost + "/schemas/fault-mysql:stable"
	// Existing immutable fixtures came from the original run. Each original
	// scenario creates its own untouched resources and preserves its assertions.
	for _, row := range []struct {
		name string
		run  func()
	}{
		{"approval-executor-image-change", f.executorImageChanges},
		{"approval-ptah-version-change", f.ptahVersionChanges},
		{"unsupported-controller-state-after-approval", f.unsupportedControllerStates},
		{"unsupported-runner-protocol-after-approval", f.unsupportedRunnerProtocols},
		{"running-apply-executor-image-change", f.runningExecutorImageChanges},
	} {
		started := time.Now()
		passed := t.Run(row.name, d.scenario(row.run))
		record := map[string]any{"scenario": row.name, "passed": passed, "startedAt": started, "finishedAt": time.Now(), "controllerImage": in.ControllerImage, "controllerRevision": in.ControllerRevision, "scope": "original scenario in retained Kubernetes 1.37 Linux amd64 lab; previous fixtures suspended; no full-phase verdict"}
		raw, err := json.MarshalIndent(record, "", "  ")
		if err != nil {
			t.Fatal(err)
		}
		d.scan(raw, "retained scenario result")
		if err := os.WriteFile("/private/tmp/ptah-585-remaining-native/"+row.name+".json", raw, 0600); err != nil {
			t.Fatal(err)
		}
		if !passed {
			return
		}
	}
}
func newRetainedDataPlane(t *testing.T, in phases.DataPlaneInputs) *dataPlane {
	t.Helper()
	d := &dataPlane{t: t, parent: t, ctx: t.Context(), in: in, evidence: map[string]*jobEvidence{}}
	// Registered before the phase creates its work directory or touches the
	// cluster, so a setup that fails part way still removes what it made.
	t.Cleanup(d.cleanup)
	for _, command := range []string{"docker", "kubectl", "helm", "go"} {
		if _, err := exec.LookPath(command); err != nil {
			d.fatalf("required command is not installed: %s", command)
		}
	}
	if err := dataPlaneInputsOK(in); err != nil {
		d.fatalf("%v", err)
	}
	if info, err := os.Stat(in.Kubeconfig); err != nil || !info.Mode().IsRegular() {
		d.fatalf("E2E_KUBECONFIG does not name a file")
	}
	d.requirePrivateFile(in.RegistryCredentialsFile, "E2E_REGISTRY_CREDENTIALS_FILE")
	d.requirePrivateFile(in.ExternalPostgresCredentialsFile, "E2E_EXTERNAL_POSTGRES_CREDENTIALS_FILE")
	for _, path := range []string{in.TLSProxyCAFile, in.TLSProxyCertFile, in.TLSProxyKeyFile} {
		d.requirePrivateFile(path, "TLS proxy input file")
	}
	d.requireSSHDockerContext()
	if info, err := os.Stat(in.ChartPackage); err != nil || !info.Mode().IsRegular() {
		d.fatalf("E2E_CHART_PACKAGE does not name a chart package")
	}

	content, err := os.ReadFile(in.RegistryCredentialsFile)
	d.check(err, "read E2E_REGISTRY_CREDENTIALS_FILE")
	if d.registry, err = parseRegistryCredentials(content); err != nil {
		d.fatalf("%v", err)
	}
	content, err = os.ReadFile(in.ExternalPostgresCredentialsFile)
	d.check(err, "read E2E_EXTERNAL_POSTGRES_CREDENTIALS_FILE")
	if d.external, err = parseExternalPostgresCredentials(content, in.ExternalPostgresService, in.TestNamespace); err != nil {
		d.fatalf("%v", err)
	}
	catalog, err := os.ReadFile(filepath.Join(repositoryRoot, "support", "ptah.json"))
	d.check(err, "read support/ptah.json")
	if d.runnerProtocol, err = edgeRunnerProtocolVersion(catalog); err != nil {
		d.fatalf("%v", err)
	}
	d.controller = controllerIdentity{
		image: in.ControllerImage, revision: in.ControllerRevision, stateVersion: in.ControllerStateVersion,
	}

	if d.cluster, err = harness.Connect(in.Kubeconfig); err != nil {
		d.fatalf("%v", err)
	}
	d.resolveController()

	d.workDir, err = os.MkdirTemp("", "ptah-operator-data-e2e.")
	d.check(err, "create the work directory")
	d.check(os.Chmod(d.workDir, 0o700), "make the work directory private")
	d.observed, d.audited, d.fullyAudited = newJobLedger(), newUIDLedger(), newUIDLedger()

	d.credentials = deriveFixtureCredentials(in.TestNamespace)
	d.registryHost = in.RegistryService + "." + in.TestNamespace + ".svc.cluster.local:5000"
	caBytes, err := os.ReadFile(in.TLSProxyCAFile)
	d.check(err, "read the TLS proxy CA")
	caSum := sha256.Sum256(caBytes)
	authority := in.TLSProxyService + "." + in.TestNamespace + ".svc.cluster.local:5443"
	d.tlsProxy = tlsProxyAddress{
		authority: authority,
		reference: "oci://" + authority + "/schemas/postgresql:stable",
		caSHA256:  "sha256:" + hex.EncodeToString(caSum[:]),
	}
	if err := tlsProxyGrantsDistinct(d.tlsProxy); err != nil {
		d.fatalf("%v", err)
	}
	if d.scanner, err = newCredentialScanner(
		d.registry.Password,
		d.credentials.pgPassword, d.credentials.pgURL, d.credentials.customCAPGURL,
		d.credentials.fourEyesPGURL, d.credentials.podMetadataPGURL,
		d.credentials.mysqlPassword, d.credentials.mysqlRootPassword, d.credentials.mysqlURL,
		d.external.Password, d.external.URL,
	); err != nil {
		d.fatalf("%v", err)
	}
	return d
}
