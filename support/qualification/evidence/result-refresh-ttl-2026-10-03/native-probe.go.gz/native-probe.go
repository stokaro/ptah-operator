//go:build e2e

package e2e

import (
	"context"
	"encoding/json"
	"os"
	"testing"
	"time"

	"github.com/stokaro/ptah-operator/test/e2e/harness"
	"github.com/stokaro/ptah-operator/test/e2e/phases"
	batchv1 "k8s.io/api/batch/v1"
	apierrors "k8s.io/apimachinery/pkg/api/errors"
)

// This diagnostic reuses a retained failed-run installation. It is not a
// completed data-plane phase and writes no phase-completion record.
func TestMain(m *testing.M) { os.Exit(m.Run()) }

func TestRetainedBlockedRefreshTTL(t *testing.T) {
	const work = "/private/var/folders/6s/s6tvscqx5j72rcd2jbxdfvrm0000gn/T/ptah-operator-e2e.QfpuKi"
	const schema = "e2e-postgresql"
	ctx, cancel := context.WithTimeout(context.Background(), 15*time.Minute)
	defer cancel()
	d := &dataPlane{t: t, parent: t, ctx: ctx, evidence: map[string]*jobEvidence{},
		observed: newJobLedger(), audited: newUIDLedger(), fullyAudited: newUIDLedger(),
		// The original native run already exercised Pod-admission adversaries.
		// This diagnostic claims only the unchanged blocked-refresh gate.
		ephemeralTested: true,
		in: phases.DataPlaneInputs{
			Kubeconfig: work + "/kubeconfig", TestNamespace: "ptah-test-a-1-37-0-pr585-durable-060a04cf-50d72969c9",
			OperatorNamespace: "ptah-system-1-37-0-pr585-durable-060a04cf-50d72969c9",
			HelmRelease:       "ptah-1-37-0-pr585-durabl-50d72969c9", DockerContext: "remote-dev-container",
		},
	}
	var err error
	d.cluster, err = harness.Connect(d.in.Kubeconfig)
	d.check(err, "connect retained installation")
	initial := d.schema(schema)
	if initial.Status.Plan == nil {
		t.Fatal("retained schema has no plan")
	}
	d.in.ControllerImage = initial.Status.Plan.ControllerImage
	d.controller = controllerIdentity{image: d.in.ControllerImage, revision: "060a04cf211f6cbef659a4c47fef31a184899583", stateVersion: "1"}
	d.runnerProtocol = 1
	d.resolveController()
	d.workDir, err = os.MkdirTemp("", "ptah-operator-data-e2e.")
	d.check(err, "create private diagnostic directory")
	t.Cleanup(d.cleanup)
	content, err := os.ReadFile(work + "/registry-credentials.json")
	d.check(err, "read registry credentials")
	d.registry, err = parseRegistryCredentials(content)
	d.check(err, "parse registry credentials")
	content, err = os.ReadFile(work + "/external-postgresql-credentials.json")
	d.check(err, "read external credentials")
	d.external, err = parseExternalPostgresCredentials(content, "e2e-postgresql-external", d.in.TestNamespace)
	d.check(err, "parse external credentials")
	d.credentials = deriveFixtureCredentials(d.in.TestNamespace)
	d.scanner, err = newCredentialScanner(d.registry.Password, d.credentials.pgPassword, d.credentials.pgURL,
		d.credentials.customCAPGURL, d.credentials.fourEyesPGURL, d.credentials.podMetadataPGURL,
		d.credentials.mysqlPassword, d.credentials.mysqlRootPassword, d.credentials.mysqlURL, d.external.Password, d.external.URL)
	d.check(err, "create credential scanner")
	d.prepareBlockedRefreshCadence(schema)
	state := d.schema(schema)
	if state.Status.Plan == nil {
		t.Fatal("resumed schema has no plan")
	}
	plan := currentPlan{name: state.Status.Plan.Name, uid: string(state.Status.Plan.UID), fingerprint: state.Status.Plan.Fingerprint}
	digest := state.Status.Plan.ArtifactDigest
	applyCheckpoint := d.checkpointJobs(schema, "apply")
	d.logf("starting unchanged three-chain gate at generation %d", state.Generation)
	d.assertDestructiveGate(schema, applyCheckpoint, plan, digest, d.blockedGate)
	records := d.observed.since(schema, "", d.blockedGate)
	d.logf("three-chain gate passed with %d exact read-only Jobs", len(records))
	if len(records) != 12 {
		t.Fatalf("expected 12 jobs, got %d", len(records))
	}
	type archiveRow struct {
		Record observedJob `json:"record"`
		Job    any         `json:"job"`
		Pod    any         `json:"pod"`
		Result any         `json:"result"`
	}
	var archive []archiveRow
	var gone []string
	for _, record := range records {
		e := d.evidence[record.UID]
		if e == nil {
			t.Fatal("missing completed archive")
		}
		archive = append(archive, archiveRow{record, e.job, e.pod, e.result})
		if err := d.get(record.Name, &batchv1.Job{}); apierrors.IsNotFound(err) {
			gone = append(gone, record.UID)
		} else if err != nil {
			t.Fatal(err)
		}
	}
	if len(gone) == 0 {
		t.Fatal("no native TTL collection observed; completion predicate alone is insufficient")
	}
	d.restoreBlockedRefreshCadence(schema, plan, digest)
	d.suspendSchemaForTagMove(schema, quiescentInterval)
	body, err := json.MarshalIndent(map[string]any{"status": "passed", "scope": "retained native blocked-refresh gate only",
		"runtimeCommit": d.controller.revision, "testCommit": "70b8cb34c7db7e125d809eb634c9ece5341319a2",
		"records": archive, "collectedJobUIDs": gone, "schemaUID": initial.UID, "intervalSeconds": 90,
		"noApply": true, "preservedPlanUID": plan.uid, "endedSuspended": true}, "", "  ")
	d.check(err, "encode diagnostic evidence")
	d.scan(body, "retained native gate evidence")
	d.check(os.WriteFile("/private/tmp/ptah-585-ttl-native/result.json", body, 0600), "retain diagnostic evidence")
	d.logf("native TTL collection confirmed for %d archived Jobs; schema suspended", len(gone))
}
