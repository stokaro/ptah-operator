//go:build e2e

package e2e

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"github.com/stokaro/ptah-operator/test/e2e/harness"
	"github.com/stokaro/ptah-operator/test/e2e/phases"
	batchv1 "k8s.io/api/batch/v1"
	corev1 "k8s.io/api/core/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"os"
	"os/exec"
	"path/filepath"
	"testing"
	"time"
)

// Focused diagnostic only. This writes no full-phase completion record.
func TestMain(m *testing.M) { os.Exit(m.Run()) }
func TestRetainedPodAdmission(t *testing.T) {
	in, err := phases.Load(phases.DataPlane, os.LookupEnv)
	if err != nil {
		t.Fatal(err)
	}
	d := newRetainedDataPlane(t, in)
	// These fixtures were created only by the failed admission scenario.
	// Remove its finished desired-state resource before resetting its database.
	d.deleteAndWait("e2e-pod-metadata-refused-postgresql", 180*time.Second)
	for _, obj := range []struct{ kind, name string }{
		{"job", "e2e-push-pod-metadata-postgresql-v1"},
		{"configmap", "e2e-pod-metadata-postgresql-v1"},
		{"secret", podMetadataPGSecret},
	} {
		_, _, err := d.cluster.Kubectl(d.ctx, "-n", in.TestNamespace, "delete", obj.kind, obj.name, "--ignore-not-found=true", "--wait=true", "--timeout=120s")
		d.check(err, "remove the failed admission fixture %s", obj.name)
	}
	_, err = d.psqlDefault("DROP DATABASE IF EXISTS " + podMetadataPGDatabase + " WITH (FORCE)")
	d.check(err, "reset only the failed admission fixture database")
	// New repository avoids touching the original write-once version.
	d.registryHost += "/admission-a19ec584"
	// Original scenario and assertions, including native refusal, no-Pod
	// cleanup, credential audit and positive convergence under the policy.
	d.scenario(d.podMetadataAdmission)(t)
	schema := d.schema("e2e-pod-metadata-postgresql")
	jobs := &batchv1.JobList{}
	d.mustList(jobs)
	var retained []any
	for _, job := range jobs.Items {
		if job.Labels[labelSchema] == schema.Name {
			retained = append(retained, job)
		}
	}
	pods := &corev1.PodList{}
	d.mustList(pods)
	var workloadPods []any
	for _, pod := range pods.Items {
		if pod.Labels[labelSchema] == schema.Name {
			workloadPods = append(workloadPods, pod)
		}
	}
	record := map[string]any{"result": "pass", "scenario": "pod-metadata-admission", "controllerImage": in.ControllerImage, "revision": in.ControllerRevision, "schema": schema, "jobs": retained, "pods": workloadPods, "completedAt": metav1.Now()}
	raw, err := json.MarshalIndent(record, "", "  ")
	d.check(err, "encode native proof")
	d.scan(raw, "retained admission evidence")
	d.check(os.WriteFile("/private/tmp/ptah-585-admission-native/result.json", raw, 0600), "retain native proof")
}
func newRetainedDataPlane(t *testing.T, in phases.DataPlaneInputs) *dataPlane {
	t.Helper()
	d := &dataPlane{t: t, parent: t, ctx: t.Context(), in: in, evidence: map[string]*jobEvidence{}}
	// Registered before the phase creates its work directory or touches the
	// cluster, so a setup that fails part way still removes what it made.
	t.Cleanup(d.cleanup)
	for _, command := range []string{"docker", "kubectl", "helm", "go"} {
		if _, err := exec.LookPath(command); err != nil {
			d.fatalf("required command is not installed: %s", command)
		}
	}
	if err := dataPlaneInputsOK(in); err != nil {
		d.fatalf("%v", err)
	}
	if info, err := os.Stat(in.Kubeconfig); err != nil || !info.Mode().IsRegular() {
		d.fatalf("E2E_KUBECONFIG does not name a file")
	}
	d.requirePrivateFile(in.RegistryCredentialsFile, "E2E_REGISTRY_CREDENTIALS_FILE")
	d.requirePrivateFile(in.ExternalPostgresCredentialsFile, "E2E_EXTERNAL_POSTGRES_CREDENTIALS_FILE")
	for _, path := range []string{in.TLSProxyCAFile, in.TLSProxyCertFile, in.TLSProxyKeyFile} {
		d.requirePrivateFile(path, "TLS proxy input file")
	}
	d.requireSSHDockerContext()
	if info, err := os.Stat(in.ChartPackage); err != nil || !info.Mode().IsRegular() {
		d.fatalf("E2E_CHART_PACKAGE does not name a chart package")
	}

	content, err := os.ReadFile(in.RegistryCredentialsFile)
	d.check(err, "read E2E_REGISTRY_CREDENTIALS_FILE")
	if d.registry, err = parseRegistryCredentials(content); err != nil {
		d.fatalf("%v", err)
	}
	content, err = os.ReadFile(in.ExternalPostgresCredentialsFile)
	d.check(err, "read E2E_EXTERNAL_POSTGRES_CREDENTIALS_FILE")
	if d.external, err = parseExternalPostgresCredentials(content, in.ExternalPostgresService, in.TestNamespace); err != nil {
		d.fatalf("%v", err)
	}
	catalog, err := os.ReadFile(filepath.Join(repositoryRoot, "support", "ptah.json"))
	d.check(err, "read support/ptah.json")
	if d.runnerProtocol, err = edgeRunnerProtocolVersion(catalog); err != nil {
		d.fatalf("%v", err)
	}
	d.controller = controllerIdentity{
		image: in.ControllerImage, revision: in.ControllerRevision, stateVersion: in.ControllerStateVersion,
	}

	if d.cluster, err = harness.Connect(in.Kubeconfig); err != nil {
		d.fatalf("%v", err)
	}
	d.resolveController()

	d.workDir, err = os.MkdirTemp("", "ptah-operator-data-e2e.")
	d.check(err, "create the work directory")
	d.check(os.Chmod(d.workDir, 0o700), "make the work directory private")
	d.observed, d.audited, d.fullyAudited = newJobLedger(), newUIDLedger(), newUIDLedger()

	d.credentials = deriveFixtureCredentials(in.TestNamespace)
	d.registryHost = in.RegistryService + "." + in.TestNamespace + ".svc.cluster.local:5000"
	caBytes, err := os.ReadFile(in.TLSProxyCAFile)
	d.check(err, "read the TLS proxy CA")
	caSum := sha256.Sum256(caBytes)
	authority := in.TLSProxyService + "." + in.TestNamespace + ".svc.cluster.local:5443"
	d.tlsProxy = tlsProxyAddress{
		authority: authority,
		reference: "oci://" + authority + "/schemas/postgresql:stable",
		caSHA256:  "sha256:" + hex.EncodeToString(caSum[:]),
	}
	if err := tlsProxyGrantsDistinct(d.tlsProxy); err != nil {
		d.fatalf("%v", err)
	}
	if d.scanner, err = newCredentialScanner(
		d.registry.Password,
		d.credentials.pgPassword, d.credentials.pgURL, d.credentials.customCAPGURL,
		d.credentials.fourEyesPGURL, d.credentials.podMetadataPGURL,
		d.credentials.mysqlPassword, d.credentials.mysqlRootPassword, d.credentials.mysqlURL,
		d.external.Password, d.external.URL,
	); err != nil {
		d.fatalf("%v", err)
	}
	return d
}
